import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
import glob
import os

# Učitaj summary
summary = pd.read_csv('outputs/experiments_summary.csv')

# Parsiraj BP, P, S iz imena (BP150_P2_S4.0)
def parse_name(name):
    if name.startswith('baseline'):
        return None, None, None
    parts = name.split('_')
    bp = int(parts[0][2:])         # BP150 -> 150
    p = int(parts[1][1:])          # P2 -> 2
    s = float(parts[2][1:])        # S4.0 -> 4.0
    return bp, p, s

summary['BP'], summary['P'], summary['S'] = zip(
    *[parse_name(n) for n in summary['experiment']]
)


# ---- 1) Survival kroz vrijeme za sve eksperimente ----
def plot_time_series():
    csv_files = {}
    for file in glob.glob('outputs/*.csv'):
        base = os.path.basename(file)
        if base == 'experiments_summary.csv':
            continue
        name = os.path.splitext(base)[0]
        csv_files[name] = file

    fig = plt.figure(figsize=(20, 10))
    ax = fig.add_subplot(1, 1, 1)

    colors = plt.cm.tab20(range(len(csv_files)))

    for (name, file), color in zip(csv_files.items(), colors):
        df = pd.read_csv(file)
        ax.plot(df['time'], df['alive_boids'],
                label=name, linewidth=1.2, color=color, alpha=0.7)

    ax.set_xlabel('Vrijeme (s)', fontsize=11)
    ax.set_ylabel('Broj živih boidova', fontsize=11)
    ax.set_title('Stopa preživljavanja kroz vrijeme (svi eksperimenti)',
                 fontsize=13, fontweight='bold')
    ax.grid(True, alpha=0.3)
    # Legenda izvan grafa zbog puno eksperimenata
    ax.legend(fontsize=5, ncol=5, bbox_to_anchor=(1.02, 1.0),
              loc='upper left', borderaxespad=0.)

    plt.tight_layout(rect=[0.03, 0.03, 0.75, 0.95])
    plt.savefig('outputs/ts_all_experiments.png', dpi=150, bbox_inches='tight')
    print(" ts_all_experiments.png spremljen u outputs/")
    plt.close()


# ---- 2) Bar chartovi finalnih metrika ----
def plot_final_bars():
    labels = summary['experiment']
    surv = summary['survival_rate'] * 100
    clusters = summary['final_clusters']
    spread = summary['final_spread']

    # Kraći prikaz naziva
    short_labels = []
    for n in labels:
        if n.startswith('baseline'):
            short_labels.append('baseline')
        else:
            # BP150_P2_S4.0 -> BP150 P2 S4
            short_labels.append(n.replace('_', ' ').replace('.0', ''))

    x = range(len(labels))
    colors = plt.cm.tab20(np.linspace(0, 1, len(labels)))

    fig, axes = plt.subplots(3, 1, figsize=(22, 12), sharex=True)
    plt.subplots_adjust(hspace=0.4)

    # survival
    ax = axes[0]
    bars = ax.bar(x, surv, color=colors, edgecolor='black', linewidth=0.8)
    ax.set_ylabel('Survival (%)', fontsize=11)
    ax.set_title('Finalna stopa preživljavanja', fontsize=13, fontweight='bold')
    ax.set_ylim(0, 110)
    ax.grid(True, axis='y', alpha=0.3)
    for b in bars:
        h = b.get_height()
        if h > 5:  # samo ako nije trivijalno
            ax.text(b.get_x() + b.get_width()/2, h + 1,
                    f'{h:.0f}', ha='center', va='bottom', fontsize=5)

    # clusters
    ax = axes[1]
    bars = ax.bar(x, clusters, color=colors, edgecolor='black', linewidth=0.8)
    ax.set_ylabel('Broj clustera', fontsize=11)
    ax.set_title('Finalna fragmentacija jata', fontsize=13, fontweight='bold')
    ax.grid(True, axis='y', alpha=0.3)

    # spread
    ax = axes[2]
    bars = ax.bar(x, spread, color=colors, edgecolor='black', linewidth=0.8)
    ax.set_ylabel('Spread', fontsize=11)
    ax.set_title('Širina jata na kraju', fontsize=13, fontweight='bold')
    ax.grid(True, axis='y', alpha=0.3)

    ax.set_xticks(x)
    ax.set_xticklabels(short_labels, rotation=45, ha='right', fontsize=6)

    plt.tight_layout()
    plt.savefig('outputs/final_bars.png', dpi=150, bbox_inches='tight')
    print(" final_bars.png spremljen u outputs/")
    plt.close()


# ---- 3) Scatter grafovi: survival vs boid_perception, speed, count ----
def plot_scatter_relations():
    # izostavi baseline (nema BP, P, S)
    df = summary.dropna(subset=['BP', 'P', 'S']).copy()

    fig, axes = plt.subplots(1, 3, figsize=(18, 5))
    plt.subplots_adjust(wspace=0.35)
    
    # Boja po broju predatora
    colors_map = {1: 'green', 2: 'orange', 3: 'red'}
    colors = [colors_map[int(p)] for p in df['P']]

    # Survival vs boid perception radius
    ax = axes[0]
    ax.scatter(df['boid_perception'], df['survival_rate'] * 100,
               c=colors, edgecolors='black', linewidths=1.0, s=60, alpha=0.7)
    ax.set_xlabel('Boid perception radius', fontsize=11)
    ax.set_ylabel('Survival (%)', fontsize=11)
    ax.set_title('Survival vs boid perception\n(zeleno=P1, narančasto=P2, crveno=P3)',
                 fontsize=11, fontweight='bold')
    ax.grid(True, alpha=0.3)

    # Survival vs predator speed
    ax = axes[1]
    ax.scatter(df['predator_speed'], df['survival_rate'] * 100,
               c=colors, edgecolors='black', linewidths=1.0, s=60, alpha=0.7)
    ax.set_xlabel('Predator speed', fontsize=11)
    ax.set_ylabel('Survival (%)', fontsize=11)
    ax.set_title('Survival vs predator speed\n(zeleno=P1, narančasto=P2, crveno=P3)',
                 fontsize=11, fontweight='bold')
    ax.grid(True, alpha=0.3)

    # Survival vs predator count
    ax = axes[2]
    # Group by predator count i prikaži boxplot
    p1 = df[df['P'] == 1]['survival_rate'] * 100
    p2 = df[df['P'] == 2]['survival_rate'] * 100
    p3 = df[df['P'] == 3]['survival_rate'] * 100
    
    bp = ax.boxplot([p1, p2, p3], labels=['1', '2', '3'],
                     patch_artist=True, widths=0.6)
    for patch, color in zip(bp['boxes'], ['green', 'orange', 'red']):
        patch.set_facecolor(color)
        patch.set_alpha(0.6)
    
    ax.set_xlabel('Broj predatora', fontsize=11)
    ax.set_ylabel('Survival (%)', fontsize=11)
    ax.set_title('Survival vs broj predatora\n(boxplot svih kombinacija)',
                 fontsize=11, fontweight='bold')
    ax.grid(True, alpha=0.3, axis='y')

    plt.tight_layout()
    plt.savefig('outputs/scatter_relations.png', dpi=150, bbox_inches='tight')
    print(" scatter_relations.png spremljen u outputs/")
    plt.close()


# ---- 4) Heatmap: Survival po BP × Speed za svaki P ----
def plot_heatmaps():
    df = summary.dropna(subset=['BP', 'P', 'S']).copy()
    
    boid_percs = sorted(df['BP'].unique())
    speeds = sorted(df['S'].unique())
    predator_counts = sorted(df['P'].unique())
    
    fig, axes = plt.subplots(1, 3, figsize=(18, 5))
    plt.subplots_adjust(wspace=0.4)
    
    for idx, p in enumerate(predator_counts):
        ax = axes[idx]
        subset = df[df['P'] == p]
        
        # Kreiraj matricu preživljavanja
        matrix = np.zeros((len(boid_percs), len(speeds)))
        for i, bp in enumerate(boid_percs):
            for j, spd in enumerate(speeds):
                row = subset[(subset['BP'] == bp) & (subset['S'] == spd)]
                if len(row) > 0:
                    matrix[i, j] = row['survival_rate'].values[0] * 100
                else:
                    matrix[i, j] = np.nan
        
        im = ax.imshow(matrix, cmap='RdYlGn', aspect='auto', vmin=0, vmax=100)
        ax.set_xticks(range(len(speeds)))
        ax.set_xticklabels([f'{s:.1f}' for s in speeds], fontsize=9)
        ax.set_yticks(range(len(boid_percs)))
        ax.set_yticklabels([f'{int(bp)}' for bp in boid_percs], fontsize=9)
        ax.set_xlabel('Predator speed', fontsize=10)
        ax.set_ylabel('Boid perception radius', fontsize=10)
        ax.set_title(f'Survival (%) - {int(p)} predator(a)', fontsize=11, fontweight='bold')
        
        # Dodaj vrijednosti u ćelije
        for i in range(len(boid_percs)):
            for j in range(len(speeds)):
                val = matrix[i, j]
                if not np.isnan(val):
                    text_color = 'white' if val < 50 else 'black'
                    ax.text(j, i, f'{val:.0f}', ha='center', va='center',
                           fontsize=8, color=text_color, fontweight='bold')
        
        plt.colorbar(im, ax=ax, fraction=0.046, pad=0.04)
    
    plt.tight_layout()
    plt.savefig('outputs/heatmaps_survival.png', dpi=150, bbox_inches='tight')
    print(" heatmaps_survival.png spremljen u outputs/")
    plt.close()


if __name__ == '__main__':
    plot_time_series()
    plot_final_bars()
    plot_scatter_relations()
    plot_heatmaps()
