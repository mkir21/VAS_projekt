import numpy as np
from src.boid import Boid
from src.predator import Predator
from src.spatial_hash import SpatialHash
from src.vector_utils import distance, normalize

class Simulation:
    """
    Glavna simulacijska klasa koja upravlja populacijom agenata,
    prostornom optimizacijom i metrikom.
    """
    
    def __init__(self, config):
        self.config = config
        self.width = config['simulation']['width']
        self.height = config['simulation']['height']
        self.dt = config['simulation']['dt']
        self.boundary_mode = config['simulation']['boundary_mode']
        
        # Inicijalizacija populacija
        np.random.seed(config.get('seed', 42))
        
        self.boids = self._create_boids()
        self.predators = self._create_predators()
        
        # Prostorna optimizacija
        cell_size = config['boids']['perception_radius']
        self.spatial_hash = SpatialHash(cell_size, self.width, self.height)
        
        # Metrike
        self.time = 0.0
        self.step_count = 0
        self.total_caught = 0
    
    def _create_boids(self):
        """Spawna jato na randomnoj poziciji (ali svi zajedno u clusteru)."""
        boids = []
        
        # Random centar jata (ali ne preblizu rubova)
        MARGIN = self.config['simulation'].get('spawn_margin', 150)
        SPAWN_RADIUS = self.config['simulation'].get('flock_spawn_radius', 80)
        
        flock_center_x = np.random.uniform(MARGIN, self.width - MARGIN)
        flock_center_y = np.random.uniform(MARGIN, self.height - MARGIN)
        flock_center = np.array([flock_center_x, flock_center_y])
        
        for _ in range(self.config['boids']['count']):
            # Random pozicija oko centra jata
            angle = np.random.uniform(0, 2 * np.pi)
            radius = np.random.uniform(0, SPAWN_RADIUS)
            offset = np.array([np.cos(angle) * radius, np.sin(angle) * radius])
            position = flock_center + offset
            
            # Random inicijalna brzina (mala, samo da se kreću)
            velocity = np.random.uniform(-1, 1, size=2)
            velocity = normalize(velocity) * np.random.uniform(0.5, 1.5)
            
            boid = Boid(position, velocity, self.config)
            boids.append(boid)
        
        return boids

    
    def _create_predators(self):
        """Spawna predatore na sigurnoj udaljenosti od jata."""
        predators = []
        
        # Izračunaj centroid jata
        if len(self.boids) > 0:
            flock_centroid = np.mean([b.position for b in self.boids], axis=0)
        else:
            flock_centroid = np.array([self.width / 2, self.height / 2])
        
        # Minimalna udaljenost od jata
        MIN_DISTANCE = self.config['simulation'].get('predator_min_distance', 300)
        
        for _ in range(self.config['predators']['count']):
            # Pokušaj naći poziciju dovoljno daleko od jata
            max_attempts = 50
            for attempt in range(max_attempts):
                # Random pozicija
                pos_x = np.random.uniform(100, self.width - 100)
                pos_y = np.random.uniform(100, self.height - 100)
                position = np.array([pos_x, pos_y])
                
                # Provjeri udaljenost od jata
                dist_to_flock = np.linalg.norm(position - flock_centroid)
                
                if dist_to_flock >= MIN_DISTANCE:
                    break  # Pronađena dobra pozicija
            
            # Inicijalna brzina predatora (pokaže prema jatu)
            direction_to_flock = flock_centroid - position
            if np.linalg.norm(direction_to_flock) > 0:
                velocity = normalize(direction_to_flock) * self.config['predators']['max_speed'] * 0.5
            else:
                velocity = np.random.uniform(-1, 1, size=2)
            
            predator = Predator(position, velocity, self.config)
            predators.append(predator)
        
        return predators

    
    def update(self):
        """
        Jedan korak simulacije:
        1. Izgradnja prostorne hash tablice
        2. Compute steering za sve agente
        3. Integracija
        4. Provjera ulova
        """
        # 1. Rebuild spatial hash
        self.spatial_hash.clear()
        for boid in self.boids:
            self.spatial_hash.insert(boid)
        
        # 2. Compute steering forces za boidove
        for boid in self.boids:
            # Pronađi susjede koristeći spatial hash (umjesto O(n²))
            neighbors = self.spatial_hash.query_radius(
                boid.position, 
                boid.perception_radius
            )
            # Ukloni samog sebe
            neighbors = [n for n in neighbors if n is not boid]
            
            steering = boid.compute_steering(neighbors, self.predators, all_boids=self.boids)
            boid.apply_force(steering)
        
        # 3. Compute steering za predatore
        for predator in self.predators:
            steering = predator.compute_steering(self.boids)
            predator.apply_force(steering)
        
        # 4. Integracija
        for boid in self.boids:
            boid.integrate(self.dt, self.width, self.height, self.boundary_mode)
        
        for predator in self.predators:
            predator.integrate(self.dt, self.width, self.height, self.boundary_mode)
        
        # 5. Provjera ulova
        self._check_predation()
        
        # 6. Update metrike
        self.time += self.dt
        self.step_count += 1
    
    def _check_predation(self):
        """Uklanja boidove koje su predatori uhvatili."""
        caught = []
        for predator in self.predators:
            for boid in self.boids:
                if predator.can_catch(boid):
                    caught.append(boid)
                    break  # Jedan boid po predatoru po koraku
        
        for boid in caught:
            if boid in self.boids:
                self.boids.remove(boid)
                self.total_caught += 1
    
    def get_metrics(self):
        """Vraća trenutne metrike za analizu."""
        if len(self.boids) == 0:
            return {
                'time': self.time,
                'alive_boids': 0,
                'avg_speed': 0.0,
                'avg_distance_to_centroid': 0.0,
                'total_caught': self.total_caught,
                'num_clusters': 0,
                'spread': 0.0
            }
        
        # Prosječna brzina
        avg_speed = np.mean([np.linalg.norm(b.velocity) for b in self.boids])
        
        # Centroid jata
        centroid = np.mean([b.position for b in self.boids], axis=0)
        
        # Prosječna udaljenost od centroida (mjera kohezije)
        avg_dist = np.mean([distance(b.position, centroid) for b in self.boids])
        
        return {
            'time': self.time,
            'alive_boids': len(self.boids),
            'avg_speed': avg_speed,
            'avg_distance_to_centroid': avg_dist,
            'total_caught': self.total_caught,
            'num_clusters': self._count_clusters(),  # ← DODANO
            'spread': self._calculate_spread()        # ← DODANO
        }
    
    def is_finished(self):
        """Provjera je li simulacija završena (svi boidovi ulovljeni)."""
        return len(self.boids) == 0


    def _count_clusters(self):
        """
        Broji broj diskretnih grupa (clustera) koristeći connectivity analysis.
        Dva boida su u istom clusteru ako su unutar 2x perception_radius.
        """
        if len(self.boids) == 0:
            return 0
        
        visited = set()
        num_clusters = 0
        cluster_distance = self.config['boids']['perception_radius'] * 2.0
        
        def dfs(boid):
            """Depth-first search za pronalaženje povezanih boidova."""
            stack = [boid]
            while stack:
                current = stack.pop()
                if current in visited:
                    continue
                visited.add(current)
                
                # Pronađi sve susjede unutar cluster_distance
                for other in self.boids:
                    if other not in visited:
                        if distance(current.position, other.position) <= cluster_distance:
                            stack.append(other)
        
        # Pronađi sve clustere
        for boid in self.boids:
            if boid not in visited:
                dfs(boid)
                num_clusters += 1
        
        return num_clusters

    def _calculate_spread(self):
        """
        Računa širinu jata (spread) kao prosječnu udaljenost svih boidova od centroida.
        Veća vrijednost = jato je rasuto, manja = jato je kompaktno.
        """
        if len(self.boids) == 0:
            return 0.0
        
        centroid = np.mean([b.position for b in self.boids], axis=0)
        distances = [distance(b.position, centroid) for b in self.boids]
        
        return np.mean(distances)

    def log_metrics(self, filename='outputs/metrics.csv'):
        """
        Sprema metrike u CSV. Kreira header ako file ne postoji.
        """
        import csv
        import os
        
        metrics = self.get_metrics()  # Sada već ima sve metrike
        
        # Provjeri postoji li file (za header)
        file_exists = os.path.isfile(filename)
        
        # Osiguraj da outputs folder postoji
        os.makedirs(os.path.dirname(filename), exist_ok=True)
        
        with open(filename, 'a', newline='') as csvfile:
            fieldnames = ['time', 'alive_boids', 'total_caught', 'avg_speed', 
                        'avg_distance_to_centroid', 'num_clusters', 'spread']
            writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
            
            if not file_exists:
                writer.writeheader()
            
            writer.writerow(metrics)


