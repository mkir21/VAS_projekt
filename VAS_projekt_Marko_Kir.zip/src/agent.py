import numpy as np
from src.vector_utils import limit_magnitude, wrap_around

class Agent:
    """
    Bazna klasa za sve agente u simulaciji.
    Svaki agent ima poziciju, brzinu i logiku za integraciju.
    """
    
    def __init__(self, position, velocity, max_speed, max_force):
        self.position = np.array(position, dtype=float)
        self.velocity = np.array(velocity, dtype=float)
        self.max_speed = max_speed
        self.max_force = max_force
        self.acceleration = np.zeros(2)
    
    def apply_force(self, force):
        """Dodaje silu na ukupnu akceleraciju (steering force)."""
        self.acceleration += force
    
    def compute_steering(self, *args, **kwargs):
        """
        Apstraktna metoda - svaki konkretni agent definira svoju logiku.
        Vraća steering force.
        """
        raise NotImplementedError("Svaki agent mora implementirati compute_steering()")
    
    def integrate(self, dt, world_width, world_height, boundary_mode):
        """
        Euler integracija: ažurira brzinu i poziciju na temelju akceleracije.
        """
        # 1. Ažuriraj brzinu
        self.velocity += self.acceleration * dt
        self.velocity = limit_magnitude(self.velocity, self.max_speed)
        
        # 2. Ažuriraj poziciju
        self.position += self.velocity * dt
        
        # 3. Primijeni granice
        if boundary_mode == "wrap":
            self.position = wrap_around(self.position, world_width, world_height)
        elif boundary_mode == "bounce":
            self._bounce_off_walls(world_width, world_height)
        
        # 4. Resetiraj akceleraciju
        self.acceleration = np.zeros(2)
    
    def _bounce_off_walls(self, width, height):
        """Refleksija na zidovima (jednostavna implementacija)."""
        if self.position[0] < 0 or self.position[0] > width:
            self.velocity[0] *= -1
            self.position[0] = np.clip(self.position[0], 0, width)
        if self.position[1] < 0 or self.position[1] > height:
            self.velocity[1] *= -1
            self.position[1] = np.clip(self.position[1], 0, height)
