import numpy as np
from src.agent import Agent
from src.vector_utils import normalize, distance

class Predator(Agent):
    """
    Predator agent: lovi najbližeg boida koristeći jednostavnu steering heuristiku.
    """
    
    def __init__(self, position, velocity, config):
        super().__init__(
            position=position,
            velocity=velocity,
            max_speed=config['predators']['max_speed'],
            max_force=0.2  # Jača steering sila od boida
        )
        self.perception_radius = config['predators']['perception_radius']
        self.attack_radius = 15.0  # Udaljenost za "ulov"
    
    def compute_steering(self, boids):
        """
        Pronalazi najbližeg VIDLJIVOG boida i ide prema njemu.
        Koristi perception_radius za ograničenje vidnog polja.
        """
        if len(boids) == 0:
            return np.zeros(2)
        
        # Filtriraj samo vidljive boide
        visible_boids = [b for b in boids 
                        if distance(self.position, b.position) < self.perception_radius]
        
        if len(visible_boids) == 0:
            # Nema ništa u vidnom polju
            return np.zeros(2)
        
        # Pronađi najbližeg vidljivog boida
        closest_boid = min(visible_boids, key=lambda b: distance(self.position, b.position))
        
        # Steering prema njemu
        desired = closest_boid.position - self.position
        
        if np.linalg.norm(desired) > 0:
            desired = normalize(desired) * self.max_speed
            steer = desired - self.velocity
            return steer
        
        return np.zeros(2)

    def can_catch(self, boid):
        """Provjerava je li boid dovoljno blizu da ga 'ulovi'."""
        return distance(self.position, boid.position) < self.attack_radius
