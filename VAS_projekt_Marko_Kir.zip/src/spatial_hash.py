import numpy as np
from collections import defaultdict

class SpatialHash:
    """
    Prostorna hash tablica za efikasno pronalaženje susjeda.
    Prostor se dijeli na grid ćelije veličine cell_size.
    """
    
    def __init__(self, cell_size, world_width, world_height):
        self.cell_size = cell_size
        self.world_width = world_width
        self.world_height = world_height
        self.grid = defaultdict(list)
    
    def clear(self):
        """Briše sve agente iz grida (poziva se svaki frame)."""
        self.grid.clear()
    
    def _hash(self, position):
        """Vraća grid koordinate (ix, iy) za danu poziciju."""
        ix = int(position[0] // self.cell_size)
        iy = int(position[1] // self.cell_size)
        return (ix, iy)
    
    def insert(self, agent):
        """Dodaje agenta u odgovarajuću ćeliju."""
        cell = self._hash(agent.position)
        self.grid[cell].append(agent)
    
    def query_radius(self, position, radius):
        """
        Vraća sve agente unutar danog radijusa od pozicije.
        Pretražuje samo relevantne ćelije (9 ćelija: centar + 8 susjeda).
        """
        cell = self._hash(position)
        cx, cy = cell
        
        # Koliko ćelija treba provjeriti u svakom smjeru
        cell_range = int(np.ceil(radius / self.cell_size))
        
        candidates = []
        for dx in range(-cell_range, cell_range + 1):
            for dy in range(-cell_range, cell_range + 1):
                neighbor_cell = (cx + dx, cy + dy)
                if neighbor_cell in self.grid:
                    candidates.extend(self.grid[neighbor_cell])
        
        # Filtriraj po stvarnoj udaljenosti
        results = []
        for agent in candidates:
            dist_sq = np.sum((agent.position - position) ** 2)
            if dist_sq <= radius ** 2:
                results.append(agent)
        
        return results
