import matplotlib.pyplot as plt
import matplotlib.animation as animation
import numpy as np

class Visualizer:
    """
    Matplotlib-bazirana vizualizacija simulacije s real-time animacijom.
    """
    
    def __init__(self, simulation, config):
        self.sim = simulation
        self.config = config
        
        # Postavljanje figure
        self.fig, self.ax = plt.subplots(figsize=(10, 10))
        
        # Dodaj margine od 50 piksela s obje strane
        margin = 50
        self.ax.set_xlim(-margin, self.sim.width + margin)
        self.ax.set_ylim(-margin, self.sim.height + margin)
        
        self.ax.set_aspect('equal')
        self.ax.set_facecolor('#0a0a0a')  # Tamna pozadina
        self.fig.patch.set_facecolor('#0a0a0a')
        
        # Nacrtaj vidljive granice simulacijskog prostora
        from matplotlib.patches import Rectangle
        boundary_rect = Rectangle((0, 0), self.sim.width, self.sim.height,
                                   linewidth=2, edgecolor='gray', 
                                   facecolor='none', linestyle='--', alpha=0.5)
        self.ax.add_patch(boundary_rect)
        
        # Inicijalni scatter plotovi
        self.boid_scatter = self.ax.scatter([], [], c='cyan', s=config['visualization']['boid_size'], 
                                            alpha=0.8, edgecolors='white', linewidths=0.5)
        self.predator_scatter = self.ax.scatter([], [], c='red', s=config['visualization']['predator_size'], 
                                                 marker='^', edgecolors='yellow', linewidths=1.5)
        
        # Quiver za smjer boidova (opcionalno)
        self.boid_quiver = None
        
        # Tekst za metrike
        self.info_text = self.ax.text(0.02, 0.98, '', transform=self.ax.transAxes,
                                       fontsize=10, verticalalignment='top',
                                       bbox=dict(boxstyle='round', facecolor='black', alpha=0.7),
                                       color='white', family='monospace')
        
        # Perception radius circle (za debug - prikaži oko jednog boida)
        self.perception_circle = plt.Circle((0, 0), 0, fill=False, 
                                            color='yellow', linestyle='--', 
                                            alpha=0.3, linewidth=1)
        self.ax.add_patch(self.perception_circle)

        self.ax.set_title('Simulacija Jata: Boidi (plava) vs Predatori (žuta)', 
                          color='white', fontsize=14, pad=20)
        self.ax.tick_params(colors='white')
        
        # Frame counter
        self.frame = 0

        # Prikaži home territory circle
        home_center = (simulation.width / 2, simulation.height / 2)
        territory_radius = min(simulation.width, simulation.height) * 0.3
        
        self.territory_circle = plt.Circle(
            home_center, territory_radius, 
            fill=False, color='white', 
            linestyle=':', linewidth=2, alpha=0.3
        )
        self.ax.add_patch(self.territory_circle)
    
    def update(self, frame_num):
        """Callback funkcija za animation - poziva se svaki frame."""
        # Update simulacije
        self.sim.update()
        self.frame += 1

        # Zapiši metrike svakih 10 frameova
        if self.frame % 10 == 0:
            self.sim.log_metrics()
        
        # Izvuci pozicije
        if len(self.sim.boids) > 0:
            boid_positions = np.array([b.position for b in self.sim.boids])
            boid_velocities = np.array([b.velocity for b in self.sim.boids])
            
            # Boja ovisi o panic stanju
            colors = ['orange' if b.is_panicking else 'cyan' for b in self.sim.boids]
            
            self.boid_scatter.set_offsets(boid_positions)
            self.boid_scatter.set_color(colors)
            
            # Quiver za smjer (opcionalno, lijepo izgleda ali može biti sporo za >200 boidova)
            if self.boid_quiver is not None:
                self.boid_quiver.remove()
            
            # Normaliziraj brzine za prikaz
            speeds = np.linalg.norm(boid_velocities, axis=1, keepdims=True)
            directions = boid_velocities / (speeds + 1e-8)
            
            # Skrati strelice tako da ne prelaze granice 
            self.boid_quiver = self.ax.quiver(
                boid_positions[:, 0], boid_positions[:, 1],
                directions[:, 0], directions[:, 1],
                color='cyan', alpha=0.4, scale=50, width=0.002
            )
        else:
            self.boid_scatter.set_offsets(np.empty((0, 2)))
        
        # Predatori
        if len(self.sim.predators) > 0:
            pred_positions = np.array([p.position for p in self.sim.predators])
            self.predator_scatter.set_offsets(pred_positions)
        
        # Ažuriraj metrike
        metrics = self.sim.get_metrics()
        info_str = (
            f"Frame: {self.frame}\n"
            f"Vrijeme: {metrics['time']:.1f}s\n"
            f"Živi: {metrics['alive_boids']}\n"
            f"Ulovljeno: {metrics['total_caught']}\n"
            f"Prosječna brzina: {metrics['avg_speed']:.2f}\n"
            f"Raspršenost: {metrics['avg_distance_to_centroid']:.1f}"
        )
        self.info_text.set_text(info_str)
        
        # Zaustavi ako su svi ulovljeni
        if self.sim.is_finished():
            print("\n⚠ Simulacija završena - svi boidi su ulovljeni!")
            self.ani.event_source.stop()
        
        if len(self.sim.boids) > 0:
            first_boid = self.sim.boids[0]
            self.perception_circle.center = first_boid.position
            self.perception_circle.radius = first_boid.perception_radius

        return self.boid_scatter, self.predator_scatter, self.info_text
    
    def run(self, frames=None, interval=None):
        """
        Pokreće animaciju.
        
        Args:
            frames: broj frameova (None = beskonačno)
            interval: delay između frameova u ms (ako None, koristi config)
        """
        if interval is None:
            fps = self.config['visualization']['fps']
            interval = 1000 // fps  # convert fps to ms
        
        if frames is None:
            frames = self.config['simulation']['steps']
        
        self.ani = animation.FuncAnimation(
            self.fig, self.update,
            frames=frames,
            interval=interval,
            blit=False,  # blit=True može biti brži ali ne radi uvijek s quiver
            repeat=False
        )
        
        plt.tight_layout()
        plt.show()
    
    def save_animation(self, filename, fps=30, duration=10):
        """Sprema animaciju kao video (zahtijeva ffmpeg)."""
        frames = int(fps * duration)
        
        self.ani = animation.FuncAnimation(
            self.fig, self.update,
            frames=frames,
            interval=1000//fps,
            blit=False
        )
        
        print(f"Spremanje animacije u {filename}...")
        self.ani.save(filename, writer='ffmpeg', fps=fps, dpi=100)
        print(" Animacija spremljena!")
