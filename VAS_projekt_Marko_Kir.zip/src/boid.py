import numpy as np
from src.agent import Agent
from src.vector_utils import normalize, limit_magnitude, distance_squared, distance

class Boid(Agent):
    """
    Boid agent koji implementira Reynolds-ova pravila:
    - Separation: izbjegavanje kolizija
    - Alignment: usklađivanje smjera sa susjedima
    - Cohesion: kretanje prema središtu mase
    + Avoidance: bijeg od predatora
    + ESCAPE ACCELERATION: ubrzanje u panici
    """
    
    def __init__(self, position, velocity, config):
        super().__init__(
            position=position,
            velocity=velocity,
            max_speed=config['boids']['max_speed'],
            max_force=config['boids']['max_force']
        )

        self.config = config

        self.perception_radius = config['boids']['perception_radius']
        self.flock_detection_radius = config['boids'].get('flock_detection_radius', 400) 

        self.weights = config['boids']['weights']
        self.world_width = config['simulation']['width']
        self.world_height = config['simulation']['height']
        
        # Stanje panike
        self.normal_max_speed = config['boids']['max_speed']
        self.panic_max_speed = config['boids']['max_speed'] * 2.0  # Dvostruko brži u panici!
        self.is_panicking = False
        self.panic_timer = 0
        self.panic_duration = 50
        self.panic_speed_multiplier = config['boids'].get('panic_speed_multiplier', 1.8)
        
        self.trap_timer = 0  # Koliko frameova je u zamci

    
    def compute_steering(self, neighbors, predators, all_boids=None):
        """
        Računanje sile upravljanja s kontekstualnim prioritetima.
        """
        steering = np.zeros(2)
        
        # 1. DETEKCIJA PANIKE 
        direct_threat = False
        closest_predator_dist = float('inf')
        
        for predator in predators:
            dist = distance(self.position, predator.position)
            if dist < closest_predator_dist:
                closest_predator_dist = dist
            
            if dist < self.perception_radius * 0.8:  # 120px
                direct_threat = True
                self.panic_timer = self.panic_duration
                break
        
        # 2. Širenje alarma 
        if not direct_threat and len(neighbors) > 0:
            self.detect_panic_in_neighbors(neighbors)
        
        # 3. Smanjenje panike 
        if self.panic_timer > 0:
            self.panic_timer -= 1
        
        self.is_panicking = (self.panic_timer > 0)
        
        if self.is_panicking:
            self.max_speed = self.panic_max_speed
        else:
            self.max_speed = self.normal_max_speed
        
        # 4. DETEKTIRAJ SITUACIJU "ZAMKE" 
        # Provjeri koliko je blizu zida
        left_dist = self.position[0]
        right_dist = self.world_width - self.position[0]
        top_dist = self.position[1]
        bottom_dist = self.world_height - self.position[1]
        min_wall_dist = min(left_dist, right_dist, top_dist, bottom_dist)
        
        # ZAMKA = blizu zida (<80px) i predator blizu (<150px)
        in_trap = (min_wall_dist < 80 and closest_predator_dist < self.perception_radius)
        
        # 5. STANJE ZAMKE: Granice DOMINIRAJU 
        if in_trap:
            self.trap_timer += 1
            # U zamci: SAMO granice (mora izbjeći zid) + tangencijalna komponenta
            boundary_force = self.avoid_boundaries_emergency(predators)
            steering += boundary_force * 20.0  # EKSTREMNA sila
            
            # SIGURNOSNI MEHANIZAM: Ako je u zamci >20 frameova, dodaj slučajni potisak
            if self.trap_timer > 3:
                random_push = np.array([np.random.uniform(-2, 2), np.random.uniform(-2, 2)])
                steering += random_push * 3.0

            # Minimalna separacija da ne udare u susjede
            if len(neighbors) > 0:
                steering += self.separation(neighbors) * 0.5
            
        # 6. NORMALNI STANJE PANIKE 
        elif self.is_panicking:
            self.trap_timer = 0  # Resetiraj brojač ako nije u zamci
            # Reynolds pravila (slabo)
            if len(neighbors) > 0:
                steering += self.separation(neighbors) * self.weights['separation'] * 2.0
                steering += self.alignment(neighbors) * self.weights['alignment'] * 0.3
                steering += self.cohesion(neighbors) * self.weights['cohesion'] * 0.2
            
            # Bijeg od predatora (jako)
            if len(predators) > 0:
                avoidance_force = self.avoid_predators(predators)
                steering += avoidance_force * 10.0
            
            # Izbjegavanje granica (jako)
            boundary_force = self.avoid_boundaries()
            steering += boundary_force * 8.0
        
        # 7. NORMALNO STANJE(bez panike) 
        else:
            self.trap_timer = 0
            
            # PONOVNO OKUPLJANJE s hitnošću 
            if len(neighbors) == 0 and all_boids is not None:
                reunion_force, urgency = self.seek_flock(all_boids)
                steering += reunion_force * urgency
            
            # Reynolds pravila
            if len(neighbors) > 0:
                steering += self.separation(neighbors) * self.weights['separation']
                steering += self.alignment(neighbors) * self.weights['alignment']
                steering += self.cohesion(neighbors) * self.weights['cohesion']
            
            if len(predators) > 0:
                avoidance_force = self.avoid_predators(predators)
                steering += avoidance_force * 2.0
            
            boundary_force = self.avoid_boundaries()
            steering += boundary_force * 5.0

        # 8. Home teritorij - UVIJEK primijeni 
        home_force = self.home_territory()
        if self.panic_timer < 10:
            # Slabija sila odmah nakon panike (postupno se vraća)
            home_strength = (10 - self.panic_timer) / 10.0
            steering += home_force * 2.0 * home_strength
        else:
            # Puna sila kad nema panike (ili je panika trajala dugo)
            steering += home_force * 3.0
        
        return limit_magnitude(steering, self.max_force * (3.0 if in_trap else (2.0 if self.is_panicking else 1.0)))



    def separation(self, neighbors):
        """
        Pravilo separacije: gura boida od previše bliskih susjeda.
        Jačina proporcionalna inverznoj udaljenosti.
        """
        steer = np.zeros(2)
        count = 0
        
        DESIRED_SEPARATION = 15.0  # Minimalna udaljenost (15 piksela)
        
        for other in neighbors:
            dist = distance(self.position, other.position)
            
            # SAMO reagiraj ako je preblizu
            if 0 < dist < DESIRED_SEPARATION:
                diff = self.position - other.position
                diff = normalize(diff)
                diff = diff / dist  # Inverzna udaljenost
                steer += diff
                count += 1
        
        if count > 0:
            steer /= count
            if np.linalg.norm(steer) > 0:
                steer = normalize(steer) * self.max_speed - self.velocity
        
        return steer

    
    def alignment(self, neighbors):
        """
        Pravilo poravnanja: usklađuje brzinu s prosječnom brzinom susjeda.
        """
        avg_velocity = np.zeros(2)
        
        for other in neighbors:
            avg_velocity += other.velocity
        
        if len(neighbors) > 0:
            avg_velocity /= len(neighbors)
            steer = normalize(avg_velocity) * self.max_speed - self.velocity
            return steer
        
        return np.zeros(2)
    
    def cohesion(self, neighbors):
        """
        Pravilo kohezije: kreće se prema središtu mase (centroid) susjeda.
        """
        center_of_mass = np.zeros(2)
        
        for other in neighbors:
            center_of_mass += other.position
        
        if len(neighbors) > 0:
            center_of_mass /= len(neighbors)
            desired = center_of_mass - self.position
            if np.linalg.norm(desired) > 0:
                desired = normalize(desired) * self.max_speed
                steer = desired - self.velocity
                return steer
        
        return np.zeros(2)
    
    def avoid_predators(self, predators):
        """
        Bijeg od predatora - koristi ISTI perception_radius kao i za susjede.
        """
        steer = np.zeros(2)
        count = 0
        
        for predator in predators:
            dist = distance(self.position, predator.position)
            
            # Koristi PERCEPTION_RADIUS
            if dist < self.perception_radius and dist > 0:
                # Panika se aktivira kad je blizu (80% radijusa = ~120px)
                if dist < self.perception_radius * 0.8:
                    self.is_panicking = True
                
                # Sila bijega - inverzno proporcionalna udaljenosti
                diff = self.position - predator.position
                
                # Jači potisak što je bliže
                if dist < 100:  # Vrlo blizu
                    diff = diff / (dist * dist)  # Inverzni kvadrat
                else:  # Dalje
                    diff = diff / dist
                
                steer += diff
                count += 1
        
        if count > 0:
            steer /= count
            if np.linalg.norm(steer) > 0:
                steer = normalize(steer) * self.max_speed - self.velocity
        
        return steer

    
    def detect_panic_in_neighbors(self, neighbors):
        """
        Detektira jesu li susjedi u panici.
        Alarm se širi samo kroz lokalne susjede, ne globalno.
        """
        fresh_panic_count = 0  # Panic timer > 40 (fresh panic)
        
        for other in neighbors:
            if hasattr(other, 'panic_timer') and other.panic_timer > 40:
                fresh_panic_count += 1
        
        # Samo ako je više od 30% susjeda u svježoj panici
        if len(neighbors) > 0:
            panic_ratio = fresh_panic_count / len(neighbors)
            if panic_ratio > 0.3:  # 30% threshold
                self.panic_timer = max(self.panic_timer, 30)  # Produži panic na 30 frameova
                return True
        
        return False


    def avoid_boundaries(self):
        """
        Standardno izbjegavanje granica - glatko skretanje.
        """
        steer = np.zeros(2)
        BOUNDARY_MARGIN = 100
        
        left_dist = self.position[0]
        right_dist = self.world_width - self.position[0]
        top_dist = self.position[1]
        bottom_dist = self.world_height - self.position[1]
        
        # Kvadratno rastući push
        if left_dist < BOUNDARY_MARGIN:
            push = (BOUNDARY_MARGIN - left_dist) / BOUNDARY_MARGIN
            steer[0] += push * push * 4.0
        
        if right_dist < BOUNDARY_MARGIN:
            push = (BOUNDARY_MARGIN - right_dist) / BOUNDARY_MARGIN
            steer[0] -= push * push * 4.0
        
        if top_dist < BOUNDARY_MARGIN:
            push = (BOUNDARY_MARGIN - top_dist) / BOUNDARY_MARGIN
            steer[1] += push * push * 4.0
        
        if bottom_dist < BOUNDARY_MARGIN:
            push = (BOUNDARY_MARGIN - bottom_dist) / BOUNDARY_MARGIN
            steer[1] -= push * push * 4.0
        
        if np.linalg.norm(steer) > 0:
            steer = normalize(steer) * self.max_speed - self.velocity
        
        return steer


    def avoid_boundaries_emergency(self, predators):
        """
        HITNO izbjegavanje granica - za situacije zamke.
        INTELIGENTNO bira tangencijalnu putanju dalje od predatora.
        """
        steer = np.zeros(2)
        
        left_dist = self.position[0]
        right_dist = self.world_width - self.position[0]
        top_dist = self.position[1]
        bottom_dist = self.world_height - self.position[1]
        
        min_dist = min(left_dist, right_dist, top_dist, bottom_dist)
        
        # Pronađi najbližeg predatora
        predator_direction = None
        if len(predators) > 0:
            closest_predator = min(predators, key=lambda p: distance(self.position, p.position))
            predator_vec = closest_predator.position - self.position
            predator_direction = normalize(predator_vec) if np.linalg.norm(predator_vec) > 0 else None
        
        # Odredi koji zid je najbliži
        if min_dist == left_dist:  # LIJEVI ZID
            # Mora ići desno (od zida)
            steer[0] = 3.0
            
            # Odluči: gore ili dolje?
            if predator_direction is not None:
                # Provjeri je li predator GORE ili DOLJE
                if predator_direction[1] < -0.3:  # Predator je GORE (negativan Y)
                    # Bježi DOLJE
                    steer[1] = 5.0
                elif predator_direction[1] > 0.3:  # Predator je DOLJE (pozitivan Y)
                    # Bježi GORE
                    steer[1] = -5.0
                else:
                    # Predator je otprilike horizontalno, bira više prostora
                    steer[1] = -4.0 if top_dist > bottom_dist else 4.0
            else:
                # Nema predatora, bira više prostora
                steer[1] = -4.0 if top_dist > bottom_dist else 4.0
        
        elif min_dist == right_dist:  # DESNI ZID
            steer[0] = -3.0
            
            if predator_direction is not None:
                if predator_direction[1] < -0.3:
                    steer[1] = 5.0  # Predator gore → bježi dolje
                elif predator_direction[1] > 0.3:
                    steer[1] = -5.0  # Predator dolje → bježi gore
                else:
                    steer[1] = -4.0 if top_dist > bottom_dist else 4.0
            else:
                steer[1] = -4.0 if top_dist > bottom_dist else 4.0
        
        elif min_dist == top_dist:  # GORNJI ZID
            steer[1] = 3.0
            
            if predator_direction is not None:
                if predator_direction[0] < -0.3:
                    steer[0] = 5.0  # Predator lijevo → bježi desno
                elif predator_direction[0] > 0.3:
                    steer[0] = -5.0  # Predator desno → bježi lijevo
                else:
                    steer[0] = -4.0 if left_dist > right_dist else 4.0
            else:
                steer[0] = -4.0 if left_dist > right_dist else 4.0
        
        elif min_dist == bottom_dist:  # DONJI ZID
            steer[1] = -3.0
            
            if predator_direction is not None:
                if predator_direction[0] < -0.3:
                    steer[0] = 5.0  # Predator lijevo → bježi desno
                elif predator_direction[0] > 0.3:
                    steer[0] = -5.0  # Predator desno → bježi lijevo
                else:
                    steer[0] = -4.0 if left_dist > right_dist else 4.0
            else:
                steer[0] = -4.0 if left_dist > right_dist else 4.0
        
        # Normaliziraj
        if np.linalg.norm(steer) > 0:
            steer = normalize(steer) * self.max_speed - self.velocity
        
        return steer


    def home_territory(self):
        """
        Privlačna sila prema centru teritorija.
        JAČA kad je boid izvan granica.
        """
        home_center = np.array([self.world_width / 2, self.world_height / 2])
        distance_from_home = distance(self.position, home_center)
        
        # Radius teritorija iz configa (ili default 400)
        TERRITORY_RADIUS = self.config['simulation'].get('home_territory_radius', 400)
        
        steer = np.zeros(2)
        
        # Ako je IZVAN teritorija
        if distance_from_home > TERRITORY_RADIUS:
            desired = home_center - self.position
            
            # EKSPONENCIJALNA sila - što je dalje, PUNO jača
            overshoot = distance_from_home - TERRITORY_RADIUS
            # Primjer: 50px izvan → strength = 0.5, 200px izvan → strength = 2.0
            strength = min((overshoot / TERRITORY_RADIUS) ** 1.5, 3.0)  # Cap na 3.0
            
            if np.linalg.norm(desired) > 0:
                desired = normalize(desired) * self.max_speed
                steer = (desired - self.velocity) * strength
        
        return steer
    
    def seek_flock(self, all_boids):
        """
        Traženje jata na velikoj udaljenosti s hitnošću za male podgrupe.
        Vraća: (steering_force, urgency_multiplier)
        """
        other_boids = [b for b in all_boids if b is not self]
        
        if len(other_boids) == 0:
            return np.zeros(2), 0.0  # ← Vraća tuple (force, urgency)
        
        # Filtriraj boide unutar flock_detection_radius
        nearby_flock = [b for b in other_boids 
                        if distance(self.position, b.position) < self.flock_detection_radius]
        
        if len(nearby_flock) == 0:
            return np.zeros(2), 0.0
        
        #  Odredi veličinu "moje" podgrupe
        my_subgroup_size = 1
        
        # Brojim susjede unutar 2x perception_radius (moja podgrupa)
        for b in other_boids:
            if distance(self.position, b.position) < self.perception_radius * 2:
                my_subgroup_size += 1
        
        #  URGENCY MULTIPLIER 
        if my_subgroup_size == 1:
            urgency = 5.0  # sam - vrlo opsano pa hitno "traži" druge
        elif my_subgroup_size < 5:
            urgency = 3.5  # Mala podgrupa (2-4 boida)
        elif my_subgroup_size < 10:
            urgency = 2.0  # Srednja podgrupa
        else:
            urgency = 0.8  # Velika podgrupa - slabo ponovno okupljanje
        
        # Središnja točka jata
        flock_centroid = np.mean([b.position for b in nearby_flock], axis=0)
        
        desired = flock_centroid - self.position
        
        if np.linalg.norm(desired) > 0:
            desired = normalize(desired) * self.max_speed
            steer = desired - self.velocity
            return steer, urgency  # ← Vraća steering i urgency
        
        return np.zeros(2), 0.0

    def update(self, dt):
        """Ažuriraj poziciju i brzinu boida."""
        self.velocity += self.acceleration * dt
        
        # Povećaj brzinu ako je panika
        current_max_speed = self.max_speed
        if self.is_panicking:
            current_max_speed *= self.panic_speed_multiplier
        
        # Ograniči brzinu
        speed = np.linalg.norm(self.velocity)
        if speed > current_max_speed:
            self.velocity = (self.velocity / speed) * current_max_speed
        
        self.position += self.velocity * dt
        self.acceleration = np.zeros(2)
