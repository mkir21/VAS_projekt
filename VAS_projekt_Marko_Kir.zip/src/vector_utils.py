import numpy as np

def normalize(vec):
    """
    Normalizira vektor na jediničnu duljinu.
    Ako je vektor nulti, vraća nulti vektor.
    """
    norm = np.linalg.norm(vec)
    if norm < 1e-8:  # Izbjegavanje dijeljenja s nulom
        return np.zeros_like(vec)
    return vec / norm

def limit_magnitude(vec, max_mag):
    """
    Ograničava magnitudu vektora na max_mag.
    Ako je vektor manji od max_mag, ostavlja ga nepromijenjenog.
    """
    mag = np.linalg.norm(vec)
    if mag > max_mag:
        return (vec / mag) * max_mag
    return vec

def distance_squared(pos1, pos2):
    """
    Vraća kvadrat euklidske udaljenosti između dvije pozicije.
    Koristi se za optimizaciju (izbjegavanje sqrt).
    """
    diff = pos2 - pos1
    return np.dot(diff, diff)

def distance(pos1, pos2):
    """
    Vraća euklidsku udaljenost između dvije pozicije.
    """
    return np.linalg.norm(pos2 - pos1)

def wrap_around(position, width, height):
    """
    Implementira 'torus' ponašanje - kada agent prođe kroz rub,
    pojavljuje se s druge strane (kao u Asteroids igri).
    """
    x, y = position
    x = x % width
    y = y % height
    return np.array([x, y])

def wrapped_difference(pos1, pos2, width, height):
    """
    Računa razliku vektora (pos2 - pos1) uzimajući u obzir wrap-around.
    Uvijek vraća najkraću razliku kroz torus topologiju.
    
    Primjer: ako je width=1000, pos1.x=50, pos2.x=980,
    direktna razlika bi bila 930, ali kroz wrap je samo 70 u drugom smjeru.
    """
    dx = pos2[0] - pos1[0]
    dy = pos2[1] - pos1[1]
    
    # Provjera je li kraći put kroz wrap
    if abs(dx) > width / 2:
        dx = dx - np.sign(dx) * width
    if abs(dy) > height / 2:
        dy = dy - np.sign(dy) * height
    
    return np.array([dx, dy])

def random_position(width, height):
    """Generiše random poziciju unutar granica svijeta."""
    return np.array([np.random.uniform(0, width), 
                     np.random.uniform(0, height)])

def random_velocity(max_speed):
    """Generiše random jedinični vektor brzine skaliran na max_speed."""
    angle = np.random.uniform(0, 2 * np.pi)
    return np.array([np.cos(angle), np.sin(angle)]) * max_speed
