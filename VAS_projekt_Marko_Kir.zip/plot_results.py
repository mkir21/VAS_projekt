import pandas as pd
import matplotlib.pyplot as plt

# Učitaj podatke
df = pd.read_csv('outputs/metrics.csv')

# Kreiraj 4 subplot grafa
fig, axes = plt.subplots(2, 2, figsize=(14, 10))
fig.suptitle('Analiza ponašanja jata kroz vrijeme', fontsize=16)

# Graf 1: Broj živih boida
axes[0, 0].plot(df['time'], df['alive_boids'], color='cyan', linewidth=2)
axes[0, 0].set_xlabel('Vrijeme (s)')
axes[0, 0].set_ylabel('Broj živih boidova')
axes[0, 0].set_title('Stopa preživljavanja')
axes[0, 0].grid(True, alpha=0.3)

# Graf 2: Broj klastera (fission-fusion)
axes[0, 1].plot(df['time'], df['num_clusters'], color='orange', linewidth=2, marker='o', markersize=3)
axes[0, 1].set_xlabel('Vrijeme (s)')
axes[0, 1].set_ylabel('Broj clustera')
axes[0, 1].set_title('Fragmentacija jata')
axes[0, 1].grid(True, alpha=0.3)

# Graf 3: Širina jata (spread)
axes[1, 0].plot(df['time'], df['spread'], color='green', linewidth=2)
axes[1, 0].set_xlabel('Vrijeme (s)')
axes[1, 0].set_ylabel('Prosječna udaljenost od centroida')
axes[1, 0].set_title('Raspršenost jata (niže = kompaktnije)')
axes[1, 0].grid(True, alpha=0.3)

# Graf 4: Prosječna brzina
axes[1, 1].plot(df['time'], df['avg_speed'], color='red', linewidth=2)
axes[1, 1].set_xlabel('Vrijeme (s)')
axes[1, 1].set_ylabel('Prosječna brzina')
axes[1, 1].set_title('Brzina jata (viša = panic mode)')
axes[1, 1].grid(True, alpha=0.3)
axes[1, 1].axhline(y=3.0, color='gray', linestyle='--', label='Normalna brzina')
axes[1, 1].axhline(y=6.0, color='yellow', linestyle='--', label='Panic brzina')
axes[1, 1].legend()

plt.tight_layout()
plt.savefig('outputs/analysis.png', dpi=150)
print(" Grafovi spremljeni u: outputs/analysis.png")
plt.show()
