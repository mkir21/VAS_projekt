import json
import os
from src.simulation import Simulation


def load_config(path):
    """Učitava konfiguracijske parametre iz JSON datoteke."""
    with open(path, 'r') as f:
        return json.load(f)


def run_simulation(config, output_file, max_steps=2000):
    """Pokreće simulaciju bez vizualizacije i sprema metrike u CSV."""
    print(f"\n{'='*70}")
    print(f"Pokrećem simulaciju: {os.path.basename(output_file)}")
    print(f"  Boids: {config['boids']['count']}")
    print(f"  Boid perception: {config['boids']['perception_radius']}")
    print(f"  Predators: {config['predators']['count']}")
    print(f"  Predator speed: {config['predators']['max_speed']}")
    print(f"{'='*70}")

    sim = Simulation(config)

    if os.path.exists(output_file):
        os.remove(output_file)

    for step in range(max_steps):
        sim.update()

        if step % 10 == 0:
            sim.log_metrics(output_file)

        if step % 100 == 0:
            m = sim.get_metrics()
            print(f"  Korak {step}/{max_steps}: "
                  f"Živi={m['alive_boids']}, "
                  f"Ulovljeno={m['total_caught']}, "
                  f"Clusteri={m['num_clusters']}")

        if sim.is_finished():
            print(f"  ⚠ Svi boidovi ulovljeni na koraku {step}")
            break

    final = sim.get_metrics()
    print(f"\n   Simulacija završena!")
    print(f"    Preživjeli: {final['alive_boids']}/{config['boids']['count']}")
    print(f"    Survival rate: {final['alive_boids']/config['boids']['count']*100:.1f}%")
    print(f"    Finalni clusteri: {final['num_clusters']}")
    print(f"    Finalni spread: {final['spread']:.1f}")

    return final


def main():
    print("="*70)
    print("EKSPERIMENTI - boid perception × predator count × speed")
    print("="*70)

    base_config = load_config('configs/config.json')

    default_boids = base_config['boids']['count']                       # 50
    default_boid_perception = base_config['boids']['perception_radius']  # 150
    default_speed = base_config['predators']['max_speed']               # 4.0

    # *** GLAVNI PARAMETRI ZA TESTIRANJE ***
    boid_perception_radii = [50, 100, 150, 200, 250]  # 5 vrijednosti
    predator_counts = [1, 2, 3]
    predator_speeds = [2.0, 3.0, 4.0, 5.0]  # 4 brzine

    experiments = []

    # --- BLOK: Boid perception × predator count × speed ---
    # Ukupno: 5 × 3 × 4 = 60 kombinacija
    for bp in boid_perception_radii:
        for p_count in predator_counts:
            for p_speed in predator_speeds:
                name = f"BP{int(bp)}_P{p_count}_S{p_speed:.1f}"
                experiments.append({
                    'name': name,
                    'params': {
                        'boids': {
                            'count': default_boids,
                            'perception_radius': bp
                        },
                        'predators': {
                            'count': p_count,
                            'max_speed': p_speed,
                            'perception_radius': 400.0  # fiksno, dovoljno velik
                        }
                    }
                })

    # --- Baseline (default config) ---
    experiments.append({
        'name': 'baseline_config',
        'params': {}
    })

    os.makedirs('outputs', exist_ok=True)
    results_summary = []

    for idx, exp in enumerate(experiments, 1):
        print(f"\n[{idx}/{len(experiments)}] ", end='')
        
        config = json.loads(json.dumps(base_config))  # deep copy

        if 'boids' in exp['params']:
            for k, v in exp['params']['boids'].items():
                config['boids'][k] = v
        if 'predators' in exp['params']:
            for k, v in exp['params']['predators'].items():
                config['predators'][k] = v

        output_file = f"outputs/{exp['name']}.csv"
        final = run_simulation(config, output_file, max_steps=2000)

        results_summary.append({
            'experiment': exp['name'],
            'boid_count': config['boids']['count'],
            'boid_perception': config['boids']['perception_radius'],
            'predator_count': config['predators']['count'],
            'predator_speed': config['predators']['max_speed'],
            'survival_rate': final['alive_boids'] / config['boids']['count'],
            'final_clusters': final['num_clusters'],
            'final_spread': final['spread']
        })

    import csv
    summary_file = 'outputs/experiments_summary.csv'
    with open(summary_file, 'w', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=results_summary[0].keys())
        writer.writeheader()
        writer.writerows(results_summary)

    print("\n" + "="*70)
    print("SAŽETAK EKSPERIMENATA")
    print("="*70)
    print(f"{'Eksperiment':<22} {'Boids':<5} {'BPerc':<6} {'P':<3} "
          f"{'Speed':<6} {'Surv%':<7} {'Clust':<6}")
    print("-"*70)
    for r in results_summary:
        print(f"{r['experiment']:<22} "
              f"{r['boid_count']:<5} {r['boid_perception']:<6.0f} "
              f"{r['predator_count']:<3} "
              f"{r['predator_speed']:<6.1f} "
              f"{r['survival_rate']*100:<7.1f} {r['final_clusters']:<6}")

    print(f"\n Svi eksperimenti završeni!")
    print(f" Ukupno eksperimenata: {len(results_summary)}")
    print(f" Detaljne metrike: outputs/*.csv")
    print(f" Sažetak: {summary_file}")


if __name__ == "__main__":
    main()
