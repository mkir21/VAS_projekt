import json
import os
import sys
import numpy as np

# Imports
from src.simulation import Simulation
from src.visualizer import Visualizer

def load_config(path):
    """Učitava konfiguracijske parametre iz JSON datoteke."""
    try:
        with open(path, 'r') as f:
            return json.load(f)
    except FileNotFoundError:
        print(f"Greška: Konfiguracijska datoteka '{path}' nije pronađena.")
        sys.exit(1)

def main():
    # Učitavanje konfiguracije
    config_path = os.path.join('configs', 'config.json')
    config = load_config(config_path)
    
    print("=== Simulacija Jata: Pokretanje vizualizacije ===\n")
    
    from src.simulation import Simulation
    from src.visualizer import Visualizer
    
    # Kreiraj simulaciju
    sim = Simulation(config)
    
    print(f"Inicijalno stanje:")
    print(f"  Boidova: {len(sim.boids)}")
    print(f"  Predatora: {len(sim.predators)}")
    print(f"  Prostor: {sim.width}x{sim.height}")
    print(f"  FPS: {config['visualization']['fps']}")
    print(f"\nPokretanje animacije...\n")
    
    # Inicijaliziraj CSV (obriši stari)
    metrics_file = 'outputs/metrics.csv'
    if os.path.exists(metrics_file):
        os.remove(metrics_file)
    
    # Vizualizacija
    viz = Visualizer(sim, config)
    viz.run(frames=2000)  # Koliko simulacija traje
    
    # Finalne metrike
    final_metrics = sim.get_metrics()
    print("\n=== Finalne Metrike ===")
    print(f"Preživjeli boidovi: {final_metrics['alive_boids']}/{config['boids']['count']}")
    print(f"Ukupno ulovljeno: {final_metrics['total_caught']}")
    print(f"Simulirano vrijeme: {final_metrics['time']:.1f}s")
    print(f"Broj clustera na kraju: {sim._count_clusters()}")
    print(f"Prosječna širina jata: {sim._calculate_spread():.2f}")
    
    print(f"\n Vizualizacija završena!")
    print(f" Metrike spremljene u: {metrics_file}")

if __name__ == "__main__":
    main()
